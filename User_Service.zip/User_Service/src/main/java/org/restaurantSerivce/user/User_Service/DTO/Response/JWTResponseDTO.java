package org.restaurantSerivce.user.User_Service.DTO.Response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class JWTResponseDTO {
    private String token;
}
