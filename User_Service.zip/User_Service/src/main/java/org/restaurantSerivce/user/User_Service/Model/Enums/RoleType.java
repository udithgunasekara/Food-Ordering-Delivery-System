package org.restaurantSerivce.user.User_Service.Model.Enums;

public enum RoleType {
    ROLE_SYSADMIN,
    ROLE_CUSTOMER,
    ROLE_RESTAURANT_ADMIN,
    ROLE_DELIVERY_AGENT
}
